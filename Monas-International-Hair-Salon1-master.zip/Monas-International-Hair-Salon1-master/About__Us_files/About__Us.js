// Created by iWeb 2.0.4 local-build-20080828

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_1:new IWShadow({blurRadius:10,offset:new IWPoint(4.2426,4.2426),color:'#000000',opacity:0.750000}),shadow_0:new IWShadow({blurRadius:10,offset:new IWPoint(4.2426,4.2426),color:'#4c4c4c',opacity:0.750000}),stroke_0:new IWStrokeParts([{rect:new IWRect(-4,-1,3,203),url:'About__Us_files/stroke.png'},{rect:new IWRect(-4,-4,3,3),url:'About__Us_files/stroke_1.png'},{rect:new IWRect(-1,-4,232,3),url:'About__Us_files/stroke_2.png'},{rect:new IWRect(231,-4,3,3),url:'About__Us_files/stroke_3.png'},{rect:new IWRect(231,-1,3,203),url:'About__Us_files/stroke_4.png'},{rect:new IWRect(231,202,3,3),url:'About__Us_files/stroke_5.png'},{rect:new IWRect(-1,202,232,3),url:'About__Us_files/stroke_6.png'},{rect:new IWRect(-4,202,3,3),url:'About__Us_files/stroke_7.png'}],new IWSize(229,201)),shadow_2:new IWShadow({blurRadius:10,offset:new IWPoint(4.2426,-4.2426),color:'#333333',opacity:0.750000}),stroke_1:new IWEmptyStroke(),reflection_0:new IWReflection({opacity:0.50,offset:2.00})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('About__Us_files/About__UsMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');fixupAllIEPNGBGs();Widget.onload();fixAllIEPNGs('Media/transparent.gif');applyEffects()}
function onPageUnload()
{Widget.onunload();}
